package JogoDaVelha;

public class JogoDaVelha { //Essa classe fica encarregada de inicar a aplica��o

    public static void main(String[] args) { // aqui � iniciado a main class do jogo 
        @SuppressWarnings("unused")
		Jogo jogo = new Jogo();
        
        
    }
    
    
}